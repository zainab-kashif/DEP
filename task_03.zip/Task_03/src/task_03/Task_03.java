
package task_03;
import java.util.*;
public class Task_03 {
    public static void factorial(){
        int number,ch;
        Scanner obj=new Scanner(System.in);
        while(true){
        long fact=1;   
        System.out.print("Enter number to calculate factorial: ");
        number=obj.nextInt();
        if(number == 0){
            System.out.println("Factorial of 0 is 1.");
        }
        else{
            for(int i=number;i>=1;i--){
                fact=fact*i; 
            }
             System.out.println("Factorial of "+number+" is "+fact);
        }
        System.out.println("Do you want to calculate factorial of any other"
        + " number(Enter any number for no/Enter 1 for yes) ");
        ch=obj.nextInt();
        if(ch!=1){
            break;
        }
        }
        System.out.println("Program End");
    }
    public static void main(String[] args) {
        factorial();
    }
}
