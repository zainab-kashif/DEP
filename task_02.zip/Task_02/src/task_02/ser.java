package task_02;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.*;

public class ser {
    private static final int PORT = 12345;
    private static Set<PrintWriter> clientWriters = new HashSet<>();
    private static JTextArea textArea;
    private static JTextArea clientListArea;
    private static Set<String> clientNames = new HashSet<>();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ser().createAndShowGUI();
            }
        });
    }

    public void createAndShowGUI() {
        JFrame frame = new JFrame("Chat Server");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        // Text area for displaying messages
        textArea = new JTextArea();
        textArea.setEditable(false);
        frame.add(new JScrollPane(textArea), BorderLayout.CENTER);

        // Panel for client list
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        clientListArea = new JTextArea();
        clientListArea.setEditable(false);
        panel.add(new JScrollPane(clientListArea), BorderLayout.CENTER);

        frame.add(panel, BorderLayout.EAST);

        // Start button
        JButton startButton = new JButton("Start Server");
        startButton.addActionListener(new StartButtonListener());
        frame.add(startButton, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    private class StartButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try (ServerSocket serverSocket = new ServerSocket(PORT)) {
                        textArea.append("Server started on port " + PORT + "\n");

                        while (true) {
                            Socket socket = serverSocket.accept();
                            textArea.append("Client connected: " + socket.getInetAddress() + "\n");
                            new ClientHandler(socket).start();
                        }
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        textArea.append("Error starting server: " + ex.getMessage() + "\n");
                    }
                }
            }).start();
        }
    }

    private class ClientHandler extends Thread {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private String clientName;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                synchronized (clientWriters) {
                    clientWriters.add(out);
                }

                // Get client name
                out.println("Enter your name:");
                clientName = in.readLine();
                synchronized (clientNames) {
                    clientNames.add(clientName);
                    updateClientList();
                }

                String message;
                while ((message = in.readLine()) != null) {
                    String formattedMessage = clientName + ": " + message;
                    textArea.append(formattedMessage + "\n");
                    synchronized (clientWriters) {
                        for (PrintWriter writer : clientWriters) {
                            writer.println(formattedMessage);
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                synchronized (clientWriters) {
                    clientWriters.remove(out);
                }
                synchronized (clientNames) {
                    clientNames.remove(clientName);
                    updateClientList();
                }
                textArea.append("Client disconnected: " + clientName + "\n");
            }
        }

        private void updateClientList() {
            StringBuilder clientList = new StringBuilder("Connected Clients:\n");
            synchronized (clientNames) {
                for (String name : clientNames) {
                    clientList.append(name).append("\n");
                }
            }
            clientListArea.setText(clientList.toString());
        }
    }
}
