package task_04;

import java.rmi.*;

public interface ResourceProvider extends Remote {
    byte[] getResource(String resourceName) throws RemoteException;
}
