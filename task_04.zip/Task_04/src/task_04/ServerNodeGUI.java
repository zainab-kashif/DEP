
package task_04;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
public class ServerNodeGUI extends javax.swing.JFrame implements ResourceProvider, ActionListener {
private final String directoryPath = "server_files";
    public ServerNodeGUI() {
        initComponents();
        this.setLocationRelativeTo(null);

        File dir = new File(directoryPath);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        initializeDirectory();
    }
    //when run the program
private void initializeDirectory() {
    File dir = new File(directoryPath);
        File[] fls = dir.listFiles();
        if (fls != null) {
            for (File fl : fls) {
                fl.delete();
            }
        }
    
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        br = new javax.swing.JButton();
        sh = new javax.swing.JButton();
        li_fi = new javax.swing.JButton();
        f_st = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Server Side");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 153));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Server");
        jLabel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 153), 2, true));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Enter File Path");

        jTextField1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        br.setBackground(new java.awt.Color(0, 51, 102));
        br.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        br.setForeground(new java.awt.Color(255, 255, 255));
        br.setText("Browse");
        br.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        br.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brActionPerformed(evt);
            }
        });

        sh.setBackground(new java.awt.Color(0, 51, 102));
        sh.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        sh.setForeground(new java.awt.Color(255, 255, 255));
        sh.setText("Share");
        sh.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shActionPerformed(evt);
            }
        });

        li_fi.setBackground(new java.awt.Color(0, 51, 102));
        li_fi.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        li_fi.setForeground(new java.awt.Color(255, 255, 255));
        li_fi.setText("List Available Files");
        li_fi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        li_fi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                li_fiActionPerformed(evt);
            }
        });

        f_st.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        f_st.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        f_st.setText("File Status");
        f_st.setBorder(null);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(158, 158, 158)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(br)
                        .addGap(28, 28, 28)
                        .addComponent(sh)
                        .addGap(28, 28, 28)
                        .addComponent(li_fi, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(f_st, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(br)
                    .addComponent(sh)
                    .addComponent(li_fi))
                .addGap(18, 18, 18)
                .addComponent(f_st, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void brActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brActionPerformed
       JFileChooser flChooser = new JFileChooser();
            int returnValue = flChooser.showOpenDialog(this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = flChooser.getSelectedFile();
                jTextField1.setText(selectedFile.getAbsolutePath());
            }
    }//GEN-LAST:event_brActionPerformed

    private void shActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shActionPerformed
         try {
                File fl = new File(jTextField1.getText());
                if (fl.exists()) {
                    // Copy the file to the server directory
                    File serverFile = new File(directoryPath, fl.getName());
                    try (FileInputStream fis = new FileInputStream(fl)) {
                        byte[] flBytes = new byte[(int) fl.length()];
                        fis.read(flBytes);
                        try (FileOutputStream fos = new FileOutputStream(serverFile)) {
                            fos.write(flBytes);
                        }
                    } catch (IOException ex) {
                        f_st.setText("Error reading file");
                        System.out.println(ex);
                        return;
                    }
                    f_st.setText("File shared successfully");
                } else {
                    f_st.setText("File not found");
                }
            } catch (Exception ex) {
                f_st.setText("Error sharing file");
                System.out.println(ex);
            }
    }//GEN-LAST:event_shActionPerformed

    private void li_fiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_li_fiActionPerformed
        listAvailableFiles();
    }//GEN-LAST:event_li_fiActionPerformed
private void listAvailableFiles() {
    File dir = new File(directoryPath);
    File[] fls = dir.listFiles(); // Use listFiles to get File objects
    if (fls != null && fls.length > 0) {
        StringBuilder flList = new StringBuilder();
        for (File fl : fls) {
            if (fl.isFile()) { // Check if it's a file (not a directory)
                flList.append(fl.getAbsolutePath()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(this, flList.toString(), "Available Files", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(this, "No files available", "Available Files", JOptionPane.INFORMATION_MESSAGE);
    }
}
    @Override
    public byte[] getResource(String resourceName) throws RemoteException {
        File fl = new File(resourceName);
        if (fl.exists()) {
            byte[] flBytes = new byte[(int) fl.length()];
            try (FileInputStream fis = new FileInputStream(fl)) {
                fis.read(flBytes);
            } catch (IOException e) {
                return null;
            }
            return flBytes;
        } else {
            return null;
        }
}

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ServerNodeGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ServerNodeGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ServerNodeGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ServerNodeGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
         try {
            LocateRegistry.createRegistry(1099);  // Create the registry on port 1099
            ServerNodeGUI serverNodeGUI = new ServerNodeGUI();
            ResourceProvider stub = (ResourceProvider) UnicastRemoteObject.exportObject(serverNodeGUI, 0);
            Naming.rebind("rmi://localhost:1099/ResourceProvider", stub);
            System.out.println("Server node is ready.");
        } catch (Exception e) {
            System.out.println("Error creating server node: " + e);
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ServerNodeGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton br;
    private javax.swing.JTextField f_st;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton li_fi;
    private javax.swing.JButton sh;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent ae) {
    }

}
